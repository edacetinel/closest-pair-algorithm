#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    srand(42); // fixed seed for reproducibility

    int sizes[] = {10, 100, 1000, 5000, 10000, 50000, 100000};
    int num_sizes = 7;

    for (int s = 0; s < num_sizes; s++) {
        int n = sizes[s];
        char filename[64];
        sprintf(filename, "inputs/input_%d.txt", n);

        FILE *f = fopen(filename, "w");
        if (!f) {
            printf("Error opening file %s\n", filename);
            return 1;
        }

        fprintf(f, "%d\n", n);
        for (int i = 0; i < n; i++) {
            double x = ((double)rand() / RAND_MAX) * 1000000.0;
            double y = ((double)rand() / RAND_MAX) * 1000000.0;
            fprintf(f, "%.6f %.6f\n", x, y);
        }

        fclose(f);
        printf("Generated: %s\n", filename);
    }

    return 0;
}
