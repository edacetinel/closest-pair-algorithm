#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>

typedef struct {
    double x, y;
} Point;

// Brute Force: O(n^2)
double brute_force(Point *pts, int n) {
    double min_dist = DBL_MAX;
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            double dx = pts[i].x - pts[j].x;
            double dy = pts[i].y - pts[j].y;
            double dist = sqrt(dx*dx + dy*dy);
            if (dist < min_dist) {
                min_dist = dist;
            }
        }
    }
    return min_dist;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "r");
    if (!f) {
        printf("Cannot open file: %s\n", argv[1]);
        return 1;
    }

    int n;
    fscanf(f, "%d", &n);

    Point *pts = (Point *)malloc(n * sizeof(Point));
    for (int i = 0; i < n; i++) {
        fscanf(f, "%lf %lf", &pts[i].x, &pts[i].y);
    }
    fclose(f);

    int RUNS = 5;
    double total_time = 0.0;
    double result = 0.0;

    // Warm-up run (ignored)
    result = brute_force(pts, n);

    // Timed runs
    for (int r = 0; r < RUNS; r++) {
        struct timespec start, end;
        clock_gettime(CLOCK_MONOTONIC, &start);
        result = brute_force(pts, n);
        clock_gettime(CLOCK_MONOTONIC, &end);

        double elapsed = (end.tv_sec - start.tv_sec) +
                         (end.tv_nsec - start.tv_nsec) / 1e9;
        total_time += elapsed;
    }

    double avg_time = total_time / RUNS;
    printf("n=%d | BruteForce | ClosestDist=%.6f | AvgTime=%.6f sec\n",
           n, result, avg_time);

    free(pts);
    return 0;
}
