#!/bin/bash

echo "=== Compiling ==="
gcc -O2 -o generate_inputs generate_inputs.c -lm
gcc -O2 -o brute_force brute_force.c -lm
gcc -O2 -o divide_conquer divide_conquer.c -lm
echo "Compilation done."

echo ""
echo "=== Generating Input Files ==="
./generate_inputs

echo ""
echo "=== Running Experiments ==="
echo ""

SIZES=(10 100 1000 5000 10000 50000 100000)

for SIZE in "${SIZES[@]}"; do
    INPUT="inputs/input_${SIZE}.txt"

    # Skip brute force for very large inputs (would take too long)
    if [ "$SIZE" -le 10000 ]; then
        ./brute_force "$INPUT"
    else
        echo "n=$SIZE | BruteForce | SKIPPED (too slow)"
    fi

    ./divide_conquer "$INPUT"
    echo "---"
done

echo ""
echo "=== Done ==="
