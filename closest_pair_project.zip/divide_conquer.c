#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>

typedef struct {
    double x, y;
} Point;

double dist(Point a, Point b) {
    double dx = a.x - b.x;
    double dy = a.y - b.y;
    return sqrt(dx*dx + dy*dy);
}

int cmp_x(const void *a, const void *b) {
    Point *pa = (Point *)a;
    Point *pb = (Point *)b;
    if (pa->x < pb->x) return -1;
    if (pa->x > pb->x) return  1;
    return 0;
}

int cmp_y(const void *a, const void *b) {
    Point *pa = (Point *)a;
    Point *pb = (Point *)b;
    if (pa->y < pb->y) return -1;
    if (pa->y > pb->y) return  1;
    return 0;
}

// Strip check for the middle band
double strip_closest(Point *strip, int size, double d) {
    double min_d = d;
    qsort(strip, size, sizeof(Point), cmp_y);

    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size && (strip[j].y - strip[i].y) < min_d; j++) {
            double distance = dist(strip[i], strip[j]);
            if (distance < min_d)
                min_d = distance;
        }
    }
    return min_d;
}

// Recursive divide and conquer
double closest_rec(Point *pts, int n) {
    // Base cases: use brute force for small n
    if (n <= 3) {
        double min_d = DBL_MAX;
        for (int i = 0; i < n; i++)
            for (int j = i+1; j < n; j++) {
                double d = dist(pts[i], pts[j]);
                if (d < min_d) min_d = d;
            }
        return min_d;
    }

    int mid = n / 2;
    Point mid_pt = pts[mid];

    double dl = closest_rec(pts, mid);
    double dr = closest_rec(pts + mid, n - mid);
    double d = dl < dr ? dl : dr;

    // Build strip
    Point *strip = (Point *)malloc(n * sizeof(Point));
    int size = 0;
    for (int i = 0; i < n; i++) {
        if (fabs(pts[i].x - mid_pt.x) < d) {
            strip[size++] = pts[i];
        }
    }

    double d2 = strip_closest(strip, size, d);
    free(strip);

    return d2 < d ? d2 : d;
}

// Divide and Conquer: O(n log n)
double divide_and_conquer(Point *pts, int n) {
    // Sort by x
    Point *sorted = (Point *)malloc(n * sizeof(Point));
    for (int i = 0; i < n; i++) sorted[i] = pts[i];
    qsort(sorted, n, sizeof(Point), cmp_x);

    double result = closest_rec(sorted, n);
    free(sorted);
    return result;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "r");
    if (!f) {
        printf("Cannot open file: %s\n", argv[1]);
        return 1;
    }

    int n;
    fscanf(f, "%d", &n);

    Point *pts = (Point *)malloc(n * sizeof(Point));
    for (int i = 0; i < n; i++) {
        fscanf(f, "%lf %lf", &pts[i].x, &pts[i].y);
    }
    fclose(f);

    int RUNS = 5;
    double total_time = 0.0;
    double result = 0.0;

    // Warm-up run (ignored)
    result = divide_and_conquer(pts, n);

    // Timed runs
    for (int r = 0; r < RUNS; r++) {
        struct timespec start, end;
        clock_gettime(CLOCK_MONOTONIC, &start);
        result = divide_and_conquer(pts, n);
        clock_gettime(CLOCK_MONOTONIC, &end);

        double elapsed = (end.tv_sec - start.tv_sec) +
                         (end.tv_nsec - start.tv_nsec) / 1e9;
        total_time += elapsed;
    }

    double avg_time = total_time / RUNS;
    printf("n=%d | DivideAndConquer | ClosestDist=%.6f | AvgTime=%.6f sec\n",
           n, result, avg_time);

    free(pts);
    return 0;
}
